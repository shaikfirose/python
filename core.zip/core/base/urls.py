from django.urls import path
from .views import *  # Ensure this imports the correct view

urlpatterns = [
    
    path('',home_view,name='home'),
    path('admin-upload/',admin_upload,name='admin-upload'), 
    path('admin-manage/',admin_manage,name='admin-manage'),
    path('admin-edit/',admin_edit,name='admin-edit'), 
    path('admin-review/',admin_review,name='admin-review'),
    path('user-claim/',user_claim,name='user-claim'),
    path('track-claim/',track_claim,name='track-claim'),
    path('view-rewards/',view_rewards,name='view-rewards'),
    path('my-points/',my_points,name='my-points'),
    path('edit-post/<int:post_id>/', admin_edit_post, name='admin-edit-post'),
    path('delete-post/<int:post_id>/', admin_delete_post, name='admin-delete-post'),
    path('submit-claim/<int:post_id>/', user_submit_claim, name='user-submit-claim'),
    path('accept-claim/<int:claim_id>/', accept_claim, name='accept-claim'),
    path('reject-claim/<int:claim_id>/', reject_claim, name='reject-claim'),
     path('forbidden/', forbidden, name='forbidden'),
    # Add more URL patterns if needed
]

