from django.db import models
from django.contrib.auth import get_user_model
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

User = get_user_model()

# Category Model
class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

# Subcategory Model
class Subcategory(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="subcategories")
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

# Reward Post Model
class RewardPost(models.Model):
    app_name = models.CharField(max_length=255)
    app_link = models.URLField()
    image = models.ImageField(upload_to='reward_images/')
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True)
    subcategory = models.ForeignKey(Subcategory, on_delete=models.SET_NULL, null=True)
    reward_points = models.IntegerField()
    admin = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'is_staff': True, 'is_admin': True}, related_name="reward_posts")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    CLAIM_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=CLAIM_STATUS_CHOICES, default='pending')

    def __str__(self):
        return f"{self.app_name} - {self.reward_points} points"

# Reward Claim Model
class RewardClaim(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'is_staff': False, 'is_admin': False}, related_name="reward_claims")
    reward_post = models.ForeignKey(RewardPost, on_delete=models.CASCADE, related_name="claims")
    screenshot = models.ImageField(upload_to='claim_screenshots/')
    claimed_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    claim_status = models.CharField(max_length=10, choices=RewardPost.CLAIM_STATUS_CHOICES, default='pending')

    def __str__(self):
        return f"Claim by {self.user.username} for {self.reward_post.app_name} - {self.claim_status}"

# Claim Request Status Model
class ClaimRequestStatus(models.Model):
    reward_post = models.OneToOneField(RewardPost, on_delete=models.CASCADE, related_name="request_status")
    pending_requests = models.IntegerField(default=0)
    accepted_requests = models.IntegerField(default=0)
    rejected_requests = models.IntegerField(default=0)

    def __str__(self):
        return f"Status for {self.reward_post.app_name}"

@receiver(post_save, sender=RewardPost)
def create_claim_request_status(sender, instance, created, **kwargs):
    if created:
        ClaimRequestStatus.objects.create(reward_post=instance)

# Signal to update claim status counts on RewardClaim creation
@receiver(post_save, sender=RewardClaim)
def update_claim_request_status_on_claim_save(sender, instance, created, **kwargs):
    status = ClaimRequestStatus.objects.get(reward_post=instance.reward_post)

    # Update the count based on the current claim status
    if created:
        if instance.claim_status == 'pending':
            status.pending_requests += 1
        elif instance.claim_status == 'accepted':
            status.accepted_requests += 1
        elif instance.claim_status == 'rejected':
            status.rejected_requests += 1
    else:
        # This will be for updates, if you want to handle them, 
        # but as per your request, we're simplifying it for now.
        pass
    
    status.save()

# Signal to update claim status counts on RewardClaim deletion
@receiver(post_delete, sender=RewardClaim)
def update_claim_request_status_on_claim_delete(sender, instance, **kwargs):
    status = ClaimRequestStatus.objects.get(reward_post=instance.reward_post)

    # Decrement the count based on the deleted claim status
    if instance.claim_status == 'pending':
        status.pending_requests -= 1
    elif instance.claim_status == 'accepted':
        status.accepted_requests -= 1
    elif instance.claim_status == 'rejected':
        status.rejected_requests -= 1
        
    status.save()
