from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import RewardPostForm,RewardClaimForm
from .models import *
from django.contrib.auth.decorators import user_passes_test
from django.utils import timezone
# from django.contrib.auth.decorators import login_required


  # Ensure this path is correct
def admin_required(user):
    return user.is_authenticated and user.is_admin


def user_required(user):
    return user.is_authenticated and not user.is_admin





def home_view(request):
    return render(request,'base/home.html')

def forbidden(request):
    return render(request, 'base/forbidden.html')


@user_passes_test(admin_required, login_url='/forbidden/')
def admin_upload(request):
    
    if request.method == 'POST':
        form = RewardPostForm(request.POST, request.FILES)
        if form.is_valid():
            reward_post = form.save(commit=False)
            reward_post.admin = request.user  # Set the admin user
            reward_post.save()            
            return redirect('home')
        else:
            # Debugging: Print form errors
            print(form.errors)
            # Redirect to the dashboard after successful upload
    else:
        form = RewardPostForm()
    
    categories = Category.objects.all()
    subcategories = Subcategory.objects.all()
    context = {
        'form': form,  # Include the form in the context
        'categories': categories,
        'subcategories': subcategories,
    }

    return render(request, 'base/admin_upload.html', context)

@user_passes_test(admin_required, login_url='/forbidden/')
def admin_edit_post(request, post_id):
    reward_post = get_object_or_404(RewardPost, id=post_id)

    if request.method == 'POST':
        form = RewardPostForm(request.POST, request.FILES, instance=reward_post)
        if form.is_valid():
            form.save()
            return redirect('admin-edit')  # Redirect to the manage posts page after editing
    else:
        form = RewardPostForm(instance=reward_post)

    categories = Category.objects.all()
    subcategories = Subcategory.objects.all()

    context = {
        'form': form,
        'categories': categories,
        'subcategories': subcategories,
        'post': reward_post,  # Pass the post object to the template
    }

    return render(request, 'base/save-changes.html', context)


@user_passes_test(admin_required, login_url='/forbidden/')
def admin_delete_post(request, post_id):
    reward_post = get_object_or_404(RewardPost, id=post_id)

    if request.method == 'POST':
        reward_post.delete()  # Delete the post
        return redirect('admin-edit')  # Redirect to the manage posts page after deleting

    return redirect('home')

@user_passes_test(admin_required, login_url='/forbidden/')
def admin_edit(request):
    reward_posts = RewardPost.objects.filter(admin=request.user)
    return render(request,'base/admin_edit.html',{'reward_posts': reward_posts})

@user_passes_test(admin_required, login_url='/forbidden/')
def admin_manage(request):
    reward_posts = RewardPost.objects.filter(admin=request.user).prefetch_related('request_status')
    return render(request,'base/admin_manage.html',{'reward_posts': reward_posts})


@user_passes_test(admin_required, login_url='/forbidden/')
def admin_review(request):

    pending_claims = RewardClaim.objects.filter(claim_status='pending').select_related('reward_post', 'user')    
    return render(request,'base/admin_review.html', {'pending_claims': pending_claims})

@user_passes_test(admin_required, login_url='/forbidden/')
def accept_claim(request, claim_id):
    claim = get_object_or_404(RewardClaim, id=claim_id)
    claim.claim_status = 'accepted'
    claim.approved_at = timezone.now()  # Set the approved time
    claim.save()
    return redirect('admin-review')  # Redirect to the review claims page

@user_passes_test(admin_required, login_url='/forbidden/')
def reject_claim(request, claim_id):
    claim = get_object_or_404(RewardClaim, id=claim_id)
    claim.claim_status = 'rejected'
    claim.save()
    return redirect('admin-review')




@user_passes_test(user_required, login_url='/forbidden/')
def user_claim(request):
    reward_posts = RewardPost.objects.all()

    # Get all claimed reward post IDs by the current user
    claimed_post_ids = RewardClaim.objects.filter(user=request.user).values_list('reward_post_id', flat=True)

    # Filter reward posts to exclude those that have already been claimed by the user
    available_rewards = reward_posts.exclude(id__in=claimed_post_ids) 
    return render(request,'base/user_claim.html',{'reward_posts': available_rewards})

@user_passes_test(user_required, login_url='/forbidden/')
def user_submit_claim(request, post_id):
    post = get_object_or_404(RewardPost, id=post_id)  # Get the reward post

    if request.method == 'POST':
        form = RewardClaimForm(request.POST, request.FILES)
        if form.is_valid():
            claim = form.save(commit=False)  # Create a claim object but don't save yet
            claim.user = request.user  # Assign the current user to the claim
            claim.reward_post = post  # Assign the reward post to the claim
            claim.save()  # Save the claim to the database
            return redirect('user-claim')  # Redirect to a success page or another appropriate view

    else:
        form = RewardClaimForm()

    return render(request, 'base/user-claim.html', {
        'post': post,
        'form': form,
    })


@user_passes_test(user_required, login_url='/forbidden/')
def track_claim(request):
    claims = RewardClaim.objects.filter(user=request.user).select_related('reward_post')
    return render(request,'base/track_claim.html', {'claims': claims})

@user_passes_test(user_required, login_url='/forbidden/')
def view_rewards(request):
    accepted_claims = RewardClaim.objects.filter(user=request.user, claim_status='accepted').select_related('reward_post')
    return render(request, 'base/view_rewards.html', {'accepted_claims': accepted_claims})


@user_passes_test(user_required, login_url='/forbidden/')
def my_points(request):
    user = request.user
    
    # Fetch total points, total claims, and status breakdown
    total_points = RewardClaim.objects.filter(user=user, claim_status='accepted').aggregate(total=models.Sum('reward_post__reward_points'))['total'] or 0
    total_claims = RewardClaim.objects.filter(user=user).count()
    pending_claims = RewardClaim.objects.filter(user=user, claim_status='pending').count()
    accepted_claims = RewardClaim.objects.filter(user=user, claim_status='accepted').count()
    rejected_claims = RewardClaim.objects.filter(user=user, claim_status='rejected').count()

    context = {
        'total_points': total_points,
        'total_claims': total_claims,
        'pending_claims': pending_claims,
        'accepted_claims': accepted_claims,
        'rejected_claims': rejected_claims,
    }
    return render(request,'base/mypoints.html',context)
