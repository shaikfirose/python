from django.contrib import admin
from django.contrib.auth import get_user_model
from base.models import *

User = get_user_model()


admin.site.register(User)
admin.site.register(Category)
admin.site.register(RewardClaim)
admin.site.register(RewardPost)
admin.site.register(ClaimRequestStatus)
admin.site.register(Subcategory)


# Register your models here.
