from django import forms
from .models import RewardPost,RewardClaim

class RewardPostForm(forms.ModelForm):
    class Meta:
        model = RewardPost
        fields = ['app_name', 'app_link', 'image', 'category', 'subcategory', 'reward_points']


class RewardClaimForm(forms.ModelForm):
    class Meta:
        model = RewardClaim
        fields = ['screenshot']