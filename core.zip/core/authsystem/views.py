from django.shortcuts import render,redirect
import requests
from django.http import JsonResponse
from django.contrib import messages
from django.contrib.auth import logout, get_user_model
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.decorators import login_required
from django.utils.deprecation import MiddlewareMixin
import jwt
from django.conf import settings
from django.contrib.auth import authenticate, login

User = get_user_model()

def password_reset_confirm(request, uid, token):
    if request.method == 'POST':
        # Capture form data
        new_password = request.POST.get('new_password')
        re_new_password = request.POST.get('re_new_password')

        # Check if the new passwords match
        if new_password != re_new_password:
            messages.info(request, "Passwords do not match.")
            return render(request, 'base/update-password.html', {'uid': uid, 'token': token})

        # Djoser API URL for password reset confirmation
        url = 'http://localhost:8000/auth/users/reset_password_confirm/'

        # Data to send to the Djoser API
        data = {
            "uid": uid,
            "token": token,
            "new_password": new_password,
            "re_new_password": re_new_password
        }

        try:
            # Make API call to Djoser for password reset confirmation
            response = requests.post(url, json=data)

            # Handle response
            if response.status_code == 204:
                messages.success(request, "Your password has been reset successfully!")
                return redirect('user-login')  # Redirect to login page after successful password reset
            else:
                try:
                    # Try to get error messages from the JSON response
                    error_data = response.json()

                    # Extract and display error messages properly
                    for field, errors in error_data.items():
                        # Errors can be a list, so iterate over each error message
                        for error in errors:
                            messages.info(request, f"{error}")
                except ValueError:
                    # If the response isn't JSON (e.g., HTML or empty), show a generic error
                    messages.info(request, "Something went wrong. Please try again.")
        except requests.exceptions.RequestException as e:
            # Handle connection errors
            messages.info(request, f"Error connecting to the password reset service: {e}")
            return render(request, 'base/update-password.html', {'uid': uid, 'token': token})

    # If it's a GET request, render the password reset confirmation form with uid and token
    return render(request, 'base/update-password.html', {'uid': uid, 'token': token})


def request_password(request):
    if request.method == 'POST':
        # Capture form data
        email = request.POST.get('email')

        # Djoser API URL for password reset
        url = 'http://localhost:8000/auth/users/reset_password/'

        # Data to send to the Djoser API
        data = {
            "email": email
        }

        try:
            # Make API call to Djoser for password reset
            response = requests.post(url, json=data)

            # Handle response
            if response.status_code == 204:
                messages.success(request, "Password reset email sent! Please check your inbox.")
                return redirect('request-password')  # Redirect to the same page after successful request
            elif response.status_code == 400:
                messages.info(request, "Invalid email address. Please try again.")
                return redirect('request-password')  # Redirect back to password reset page
            else:
                # Handle any other errors returned by Djoser
                messages.info(request, "Password reset failed. Please try again.")
                return redirect('request-password')  # Redirect back to password reset page

        except requests.exceptions.RequestException as e:
            # Handle connection errors
            messages.info(request, f"Error connecting to the password reset service: {e}")
            return redirect('request-password')  # Redirect back to password reset page    
    return render(request,'base/request_reset.html')

from django.contrib.auth import authenticate, login
from django.shortcuts import redirect, render
from django.contrib import messages
import requests

def admin_login(request):
    if request.method == 'POST':
        # Capture form data
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Djoser API URL for JWT creation (login)
        url = 'http://localhost:8000/auth/jwt/create/'

        # Data to send to the Djoser API
        data = {
            "email": email,
            "password": password
        }

        try:
            # Make API call to Djoser for login
            response = requests.post(url, json=data)

            # Handle response
            if response.status_code == 200:
                # Extract the JWT tokens from the response
                token_data = response.json()
                access_token = token_data.get('access')
                refresh_token = token_data.get('refresh')

                # Optionally, store the tokens in session or cookie for later use
                request.session['access_token'] = access_token
                request.session['refresh_token'] = refresh_token

                # Authenticate user with Django's built-in auth system
                user = authenticate(request, username=email, password=password)
                
                # Check if the user is an admin
                if user is not None and user.is_admin:
                    login(request, user)
                    return redirect('home')  # Redirect to some authenticated page after login
                else:
                    # User is authenticated but not an admin
                    messages.info(request, "You do not have admin access.")
                    return redirect('home')  # Redirect to home without logging in

            elif response.status_code == 401:
                messages.info(request, "Invalid credentials. No active account found.")
                return redirect('admin-login')

            else:
                # Handle any other errors returned by Djoser
                messages.info(request, "Login failed. Please try again.")
                return redirect('admin-login')

        except requests.exceptions.RequestException as e:
            # Handle connection errors
            messages.info(request, f"Error connecting to the login service: {e}")
            return redirect('admin-login')

    return render(request, 'base/authentication-admin.html')



def user_register(request):
    if request.method == 'POST':
        # Capture form data
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')

        # Ensure that passwords match
        if password != password2:
            messages.info(request, "Passwords do not match.")
            return render(request, 'authentication-register.html')

        # Djoser API URL for Registration
        url = 'http://localhost:8000/auth/users/'

        # Data to send to the Djoser API
        data = {
            "name": username,
            "email": email,
            "password": password,
            "re_password": password2
        }

        try:
            # Make API call to Djoser
            response = requests.post(url, json=data)

            # Handle response from Djoser
            if response.status_code == 201:
                messages.success(request, "Registration successful! Please check your email to activate your account.")
                return redirect('user-login')  # Redirect to login page after successful registration
            else:
                try:
                    # Try to get error messages from the JSON response
                    error_data = response.json()

                    # Extract and display error messages properly
                    for field, errors in error_data.items():
                        # Errors can be a list, so iterate over each error message
                        for error in errors:
                            messages.info(request, f"{error}")
                except ValueError:
                    # If the response isn't JSON (e.g., HTML or empty), show a generic error
                    messages.info(request, "Something went wrong. Please try again.")
        except requests.exceptions.RequestException as e:
            messages.info(request, f"Error connecting to the registration service: {e}")

        return render(request, 'base/authentication-register.html')

    return render(request, 'base/authentication-register.html')

def activate_account(request, uid, token):
    url = 'http://localhost:8000/auth/users/activation/'  # Djoser's activation endpoint
    data = {
        'uid': uid,
        'token': token
    }

    response = requests.post(url, json=data)
    
    if response.status_code == 204:  # Successful activation
        messages.success(request, "Account activated successfully! You can now log in.")
        return redirect('user-login')
    else:
        messages.error(request, "Activation failed. The link might have expired or is invalid.")
        return redirect('user-register')

# Login View
def user_login(request):
    if request.method == 'POST':
        # Capture form data
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Djoser API URL for JWT creation (login)
        url = 'http://localhost:8000/auth/jwt/create/'

        # Data to send to the Djoser API
        data = {
            "email": email,
            "password": password
        }

        try:
            # Make API call to Djoser for login
            response = requests.post(url, json=data)

            # Handle response
            if response.status_code == 200:
                # Extract the JWT tokens from the response
                token_data = response.json()
                access_token = token_data.get('access')
                refresh_token = token_data.get('refresh')
                # print(access_token)
                # print(refresh_token)

                # Optionally, store the tokens in session or cookie for later use
                request.session['access_token'] = access_token
                request.session['refresh_token'] = refresh_token
                user = authenticate(request, username=email, password=password)
                
                login(request, user)
                

                
                return redirect('home')  # Redirect to some authenticated page after login
            elif response.status_code == 401:
                messages.info(request, "Invalid credentials. No active account found.")
                return redirect('user-login')
            else:
                # Handle any other errors returned by Djoser
                messages.info(request, "Login failed. Please try again.")
                return redirect('user-login')

        except requests.exceptions.RequestException as e:
            # Handle connection errors
            messages.info(request, f"Error connecting to the login service: {e}")
            return redirect('user-login')


    return render(request, 'base/authentication-login.html')
    


def user_logout(request):
    
    if request.method == 'POST':
        
        
        if request.user.is_authenticated:
            
            logout(request)  # Clear all session data
            
            messages.success(request, "Successfully logged out.")
            return redirect('home')
        else:
            messages.info(request, "something went wrong!!!.")
            return redirect('home')