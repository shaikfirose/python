
from django.contrib import admin
from django.urls import path,include,re_path
from . import views

urlpatterns = [
    
      # Maps the root URL to the index view
    
    path('auth/', include('djoser.urls')),
    path('auth/', include('djoser.urls.jwt')),
    path('admin-login/',views.admin_login,name='admin-login'),
    path('user-login/',views.user_login,name='user-login'),
    path('user-logout/',views.user_logout,name='user-logout'),
    path('user-register/',views.user_register,name='user-register'),
    path('activate/<str:uid>/<str:token>/', views.activate_account, name='activate-account'),
    path('request-password/',views.request_password,name='request-password'),
    path('password/reset/confirm/<str:uid>/<str:token>/', views.password_reset_confirm, name='password-reset-confirm'),
]

